<?php
session_start();

//!!!ЭТО АДМИНСКИЙ КЛАСС!!!!
/**
 * Description of Acore
 *
 * @author Я
 */
require_once 'ADB.php';

abstract class Acore_A extends ADB {

public function __construct(){
    
    if ($_SESSION['Id_user']=='')
        
        {header("Location: /Auth.php");}
 else {
    parent::__construct();
    $this->get_Body();    
}

}

protected function PrintMsg($MSG){
    If ($MSG<>'')
    echo '<p style="height: 25px; color: red;">'.$MSG.'</p> </BR>';
    unset($_SESSION['$Message']);
}



protected function get_Header()
        {
    include 'Header.php';
    include 'menu.php';
    
        }

protected function get_LeftBar()
        {

    }
    
    protected function get_Footer()
    {
        include 'ver.php';
        echo '
         
    </body> 
    </html>';
        
    }
    public function get_Body()
    {
       if ($_POST||$_GET){
          $this->obr();   
        }
       
    $this->get_Header();
    $this->get_LeftBar();
    $this->Get_Content();
    $this->get_Footer();
    }
    
    abstract function Get_Content();
    
    protected function obr()
    {}
  
    public function MainTabel($Table)  
    {
     $arr=$this->GetStructTable($Table);
        //var_dump($arr);
        //Name, Type Length Comment
        $str='';
        // выводим на страницу сайта заголовки HTML-таблицы
        $str=$str.'<table class="col_12  sortable" cellspacing="0" cellpadding="0">';
	//echo $col;
	$str=$str. '<thead><tr class="alt first last">';
        foreach ($arr as $key => $value) {
             
        $str=$str. '<th value="'.$value['Name'].'" rel="'.$key.'">'.$value['Comment'].'</th>';
       }
        //echo '<th>Завершена</th>';
	$str=$str. '</thead></tr>';
	//echo '</thead>';
	//echo '<tbody>';
	$str=$str.'<tbody>';
        $query="Select * from ".$Table;
        $Res=  $this->query($query);
        while($data = $Res->fetch_row()){ 
                $col--;
                //echo $COL.'</Br>';
                //echo $col.'</Br>';
                                 
                iF ($col1==1) {
                $str=$str. '<tr class="alt">';
                $col1--;
                } 
                Else
                {
		$str=$str. '<tr class="">';
		 $col1++;
                };
                
                foreach ($data as $key => $value){
                    If ($key==0){
                        $str=$str. '<td value="'.$value.'" >
                                <a href="?option=Defaul&Act=Edit&id='.$value.'">'.$value.'</a> </td>';
                    }
                    else {
                    $str=$str. '<td value="'.$value.'" >' . $value . '</td>';
                    
                    }
                }
                $str=$str. '</tr>';
                
        }
        
        
        
        $str=$str.'</tbody></table>';
        echo $str;
    //echo "Ключ: $key; Значение: $value<br />\n";
  // echo ; echo $value['Type']; echo $value['Length']; echo $value['Comment']; echo'</br>';

}

function FieldGenerate($Type,$Name,$Label,$Value,$IdEdit=FALSE){
    //echo $Type.'</BR>';
        switch($Type){
           case 'varchar':
               return '<p>'.$Label.' <input name="'.$Name.'" value="'.$Value.'" </p>';
               break;
           case 'tinyint':
               return '<p>'.$Label.' <input name="'.$Name.'" value="'.$Value.'" </p>';
               break;
           case 'int':
               If ($Name<>'Id' or $IdEdit==True){
               return '<p>'.$Label.' <input name="'.$Name.'" value="'.$Value.'" </p>';}
               break;
           
           
        }
//<p> Поиск УПФР по классификатору: </BR> <input name="SearchField" placeholder="Поиск УПФР по справочнику" style="width: 100%" class="searchUPFR">
}
}
