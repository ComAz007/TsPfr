<?php
    
//http://blog.sklazer.com/865.html почитать для просветления!

class viewJurVipnet extends Jurnals {
    
    public function __construct() {
        include 'Header.php';
        parent::__construct();
        
    }
    
    private function Table($Res){
    //`Id`, `DataReg`, `KodReg`, `KodUrLic`, `KodUpfr`, `FIOZL`, `IdUserCreate`, `TypeZapros`, `TypeZaprosId`, `TypeDeistv`, `FileZapr`, `Povtor`, `DatePovtor`, `DateOtveta`, `FileOtv`
     $str='';
        // выводим на страницу сайта заголовки HTML-таблицы
        $str=$str.'<table class="col_12  sortable" cellspacing="0" cellpadding="0">';
	//echo $col;
	$str=$str. '<thead><tr class="alt first last">';
        $str=$str. '<th value="Napr" rel="13">Направ ление</th>';
        $str=$str. '<th value="SN" rel="0">Рег №</th>';
	$str=$str. '<th value="DC" rel="1">Дата</th>';
	$str=$str. '<th value="R" rel="2">Регион</th>';
	$str=$str. '<th value="UL" rel="3">Юр Лицо</th>';
        $str=$str. '<th value="UP" rel="4">УПФР</th>';
        $str=$str. '<th value="FZL" rel="5">На кого запрос </th>';
        $str=$str. '<th value="cr" rel="6">Отправил/ Принял</th>';
        $str=$str. '<th value="TZ" rel="7">Тип запроса</th>';
        $str=$str. '<th value="TZU" rel="7">Уточнение</th>';
        $str=$str. '<th value="ZP" rel="9">Заблаговременный</th>';
        $str=$str. '<th value="ZP" rel="14">ответственный</th>';
        $str=$str. '<th value="Pv" rel="10">Повтор</th>';
        $str=$str. '<th value="Dpv" rel="11">Дата Повтора</th>';
        $str=$str. '<th value="DO" rel="12">Дата Ответа</th>';
        
        //echo '<th>Завершена</th>';
	$str=$str. '</thead></tr>';
	//echo '</thead>';
	//echo '<tbody>';
	$str=$str.'<tbody>';
        
        
        while($data = $Res->fetch_row()){ 
                $col--;
                //echo $COL.'</Br>';
                //echo $col.'</Br>';
                                 
                iF ($col1==1) {
                $str=$str. '<tr class="alt">';
                $col1--;
                } 
                Else
                {
		$str=$str. '<tr class="">';
		 $col1++;
                };
                
                
                //Формирование ВХДИ-ИСХД
                $Type=$this->getTypeZ($data['13']);
                $str=$str. '<td value="'.$Type.'">' .$Type.'</td> ';
                
                //Начали формировать функционал столбца Рег №
                $str=$str. '<td value="'.$data['0'].'">' .$data['0'];
                
                //Если дата ответа не стоит то выводим такую возможность
                IF ($data['12']==0) {
                
                //Если ИСДИ
                If ($data['13']==0) {
                    
                    if ($data['10']==0){
                           $str=$str.'</BR> <a href="?option=CreateZapros&Act=PovtISXD&id='.$data['0'].' ">Повтор</a> ';
                    }
                    
                    $str=$str.'</BR> <a href="?option=CreateZapros&Act=3&id='.$data['0'].' ">Принять ответ</a>  ';
                }
                
                //Если ВХДИ
                If ($data['13']==1) {
                        
                        //Если ответственного нет то функционал доступен
                        IF ($data['14']==0) {
                        $str=$str.'</BR> <a href="?option=CreateZapros&Act=2&id='.$data['0'].' ">Ответственный</a>  ';
                        };
                        
                        //$str=$str.'</BR> <a href="?option=viewJurVipnet&Act=Peres&id='.$data['0'].' ">Переслать</a>  ';   
                        $str=$str.'</BR> <a href="?option=CreateZapros&Act=Peres&id='.$data['0'].' ">Переслать</a>  ';   
                        
                        //Если роль не 22 то доступна возможность ответа.
                        If ($_SESSION['Status']<>22){
                                $str=$str.'</BR> <a href="?option=CreateZapros&Act=Msg&id='.$data['0'].' ">Послать ответ</a>  ';
                            }
                        }                       
                }
                        $str=$str.'</td>';                
                
                //Окончили формировать функционал столбца Рег №
                        
                        
		$str=$str. '<td value="'.$data['1'].'" >' . $data['1'] . '</td>';
                $str=$str. '<td value="'.$data['2'].'" >' .$data['2']. '</td>';
                $str=$str. '<td value="'.$data['3'].'" >' . $data['3'] . '</td>';
                $str=$str. '<td value="'.$data['4'].'" >' . $data['4']. '</td>';
                $str=$str. '<td value="'.$data['5'].'" >' . $data['5'] . '</td>';
                $str=$str. '<td value="'.GetUserName($data['6']).'" >' . GetUserName($data['6']). '</td>';
                $str=$str. '<td value="'.$data['7'].'" >' . $data['7'] . '</td>';
                $str=$str. '<td value="'.$data['8'].'" >' . $data['8'] . '</td>';
                $str=$str. '<td value="'.$data['9'].'" >' . $this->getEsNo($data['9']) . '</td>';
                 $str=$str. '<td value="'.$data['14'].'" >'. GetUserName( $data['14'] ). '</td>';
                $str=$str. '<td value="'.$data['10'].'" >' . $this->getEsNo($data['10']) . '</td>';
                $str=$str. '<td value="'.$data['11'].'" >' . $data['11'] . '</td>';
                $str=$str. '<td value="'.$data['12'].'" >' . $data['12'] . '</td>';
                $str=$str. '</tr>';
                 

	}
        
      $str=$str.'</tbody></table>';
        //return $str;
        echo $str;
        
}


    public function Get_Content()
  {
        echo "<Center> <H6> Журнал регистрации направления поступления и исполнения запросов (Распоряжение Правления ПФР 463Р от 06.10.2015) </Center> </H6>";
        echo '<ul class="tabs left">
<li><a href="#tabr2">Запросы в обработке</a></li>
<li><a href="#tabr1">Запросы обработанные</a></li>
</ul>';
        Echo ('<div id="tabr2" class="tab-content">');
        $IDU = $_SESSION['Id_user'];
        echo "<div class='col_3 visible center' style='height: 25px;'> <a href='?option=CreateZapros' title='Создать задание'>Создать запрос</a></div>";
        //echo "<div class='col_3 visible center ' style='height: 25px;'> <a class='FormMini fancybox.ajax' href='?option=CreateZapros&Act=PZ'>Принять запрос</a></div>";
        echo "<div class='col_3 visible center' style='height: 25px;'> <a href='?option=CreateZapros&Act=PZ'>Принять запрос</a></div>";
        echo "<div class='col_3 visible center' style='height: 25px;'> <a href='#'>Фиктивный запрос</a></div>";
        
        If (($_SESSION['Admin']==1) or ($_SESSION['Status']==21))
         {
            $query="SELECT Id,DataReg,KodReg,KodUrLic,KodUpfr,FIOZL,IdUserCreate,TypeZapros,TypeDeistv,ZR,Povtor,DatePovtor,DateOtveta,Napravl,Otvetstv FROM jurvipnetzapros Where DateOtveta is NULL Order By Id DESC LIMIT 30";             
         }
         
        If ($_SESSION['Status']==20) 
         {
           $query="SELECT Id,DataReg,KodReg,KodUrLic,KodUpfr,FIOZL,IdUserCreate,TypeZapros,TypeDeistv,ZR,Povtor,DatePovtor,DateOtveta,Napravl,Otvetstv FROM jurvipnetzapros Where ( (IdUserCreate='$IDU')  or  (Otvetstv='$IDU') ) and (DateOtveta is NULL)  Order By Id DESC LIMIT 30";             
         }


         If ($_SESSION['Status']==0)
         {
            $query="SELECT Id,DataReg,KodReg,KodUrLic,KodUpfr,FIOZL,IdUserCreate,TypeZapros,TypeDeistv,ZR,Povtor,DatePovtor,DateOtveta,Napravl,Otvetstv FROM jurvipnetzapros Where (IdUserCreate='$IDU') and (DateOtveta is NULL) Order By Id DESC LIMIT 30";
         }

         If ($_SESSION['Status']==22)
         {
            $query="SELECT Id,DataReg,KodReg,KodUrLic,KodUpfr,FIOZL,IdUserCreate,TypeZapros,TypeDeistv,ZR,Povtor,DatePovtor,DateOtveta,Napravl,Otvetstv FROM jurvipnetzapros Where (IdUserCreate='$IDU') and (Otvetstv=0) Order By Id DESC LIMIT 30"; 
         }
        $Res= $this->query($query);
        
        
         If ($Res<>NULL){
        $this->Table($Res);}
   Echo '</div>';
   
   Echo ('<div id="tabr1" class="tab-content">');
   $query="SELECT Id,DataReg,KodReg,KodUrLic,KodUpfr,FIOZL,IdUserCreate,TypeZapros,TypeDeistv,ZR,Povtor,DatePovtor,DateOtveta,Napravl,Otvetstv FROM jurvipnetzapros Where DateOtveta is NOT NULL Order By DateOtveta DESC";             
   $Res=$this->query($query);
   $this->Table($Res);
   Echo '</div>';
   
        
     
  }
  
  
}
