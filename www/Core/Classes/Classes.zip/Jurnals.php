<?php
class Jurnals extends Acore_A{
     
    protected function getTypeZ($type) {
   $arrays = array(
                0=>'ИСХД',
                1=>'ВХДИ',
                2=>'ПЕРЕ'
               );
    return $arrays[$type];
    }
    
    protected  function getEsNo($type) {
   $arrays = array(
                0=>'Нет',
                1=>'Да',
               );
    return $arrays[$type];
    }
    
    protected  function getTypeZ2($type) {
        $arrays = array(
            1 => 'ЗСИД',
            2 => 'ОСИД',
            3 => 'ЗИЛС',
            4 => 'ОИЛС',
            5 => 'ЗП',
            6 => 'ОП',
            7 => 'ЗОС',
            8 => 'ООС');
        return $arrays[$type];
    }
    
    protected  function getTypeZ1($type) {
        $arrays = array(
            ЗСИД => '1',
            ОСИД => '2',
            ЗИЛС => '3',
            ОИЛС => '4',
            ЗП => '5',
            ОП => '6',
            ЗОС => '7',
            ООС => '8');
        return $arrays[mb_strtoupper($type)];
    }
   
    
    public function Get_Content(){
        echo '<div class="col_12 column">';
        echo '<a href="?option=viewJurVipnet"><H6> Журнал регистрации направления поступления и исполнения запросов (Распоряжение Правления ПФР 463Р от 06.10.2015)</H6></a>';
        echo '</div>';
       
    }
    
}


        
    