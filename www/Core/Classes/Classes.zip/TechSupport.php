<?php
class TechSupport extends Acore_A{
       
    public function Get_Content(){
        echo '<div class="col_12 column">';
        echo '<a href="?option=TechSupport"><H6> Обновленная ТП </H6></a>';
        echo '</div>';
 Echo '       
<ul class="tabs left">
<li><a href="#tabr2">Задания открытые</a></li>
<li><a href="#tabr1">Все задания</a></li>
<li><a href="#tabr3">Задания исполненные</a></li>
</ul>';

Echo '<div id="tabr2" class="tab-content">';
Echo '<div class="col_3 visible center" style="height: 25px;"> <a href="AddZadan.php" title="Создать задание">Создать задание</a></div> </Br></Br></Br>
  <div id="content"></div>';
Echo '</div>';

                Echo ('<div id="tabr1" class="tab-content">');
               // echo "<div class='col_12'>";
                

                If ($_SESSION['Status']!='1' and $_SESSION['Admin']!='1')
                Echo TableOut(0,$dats,$_SESSION['Id_user'],'');
                Else

                Echo TableOut(0,'','',pagination1());
                echo '</Br>';

                Echo ('</div>'); // id="tabr1" class="tab-content"
                
                
                
                Echo ('<div id="tabr3" class="tab-content">'); 
                    If ($_SESSION['Status']!='1' and $_SESSION['Admin']!='1')
                    Echo TableOut(2,'',$_SESSION['Id_user'],'');
                    Else
                    Echo TableOut(2,'','','');
                Echo ('</div>');
            
           
            
            unset($_SESSION['Message']);   
}
    
}